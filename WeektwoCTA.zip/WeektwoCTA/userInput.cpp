/*
 * userInput.cpp
 *
 *  Created on: Sep 21, 2025
 *      Author: Aerionna Stephenson
 */

#include <iostream>
#include <string>
using namespace std;


int main(){
	string firstWord = "";
	string secondWord = "";
	string fullWord = "";
	for (int i=0; i<3; i++){
		cout << "Please enter the first word." << endl;
		cin >> firstWord;
		cout << "Please enter the second word." << endl;
		cin >> secondWord;
		fullWord = firstWord + " " + secondWord;
		cout << "Your new word is " << fullWord << endl;
		}

return 0;
}
